=============
Announcements
=============

.. include:: announcements/2020-05-12-release-v2-8-0.rst

.. include:: announcements/2020-05-07-release-v2-7-0.rst

Previous announcements
----------------------

Find previous announcements in the :doc:`announcement_archive`.