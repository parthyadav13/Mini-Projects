=====
Model
=====

.. currentmodule:: pandas_profiling.model
.. toctree::

.. autosummary::
   :toctree: _autosummary

   base
   describe
   summary
   messages
   correlations
