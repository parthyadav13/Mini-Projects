"""
Test for issue XXX:
https://github.com/pandas-profiling/pandas-profiling/issues/XXX
"""
import pandas as pd

import pandas_profiling


def test_issueXXX():
    # Minimal reproducible code
    # df = pd.read_csv(r"<file>")
    pass
